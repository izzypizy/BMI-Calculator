package com.example.bmicalculator;

import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ImageView;


import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    EditText weight, height;
    Button btnCalculate, btnReset;
    TextView bmiCategory, bmi, healthRisk, text1, text2, text3;
    Intent intent;
    public static final String SHARED_PREFS = "sharedPrefs";
    public static final String TEXT = "height";
    public static final String TEXT2 = "weight";
    private String heightString, weightString;



    @Override
    protected void onCreate(Bundle savedInstanceState) {



        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        weight = (EditText) findViewById(R.id.weight);
        height = (EditText) findViewById(R.id.height);
        text1 = (TextView) findViewById(R.id.text1);
        text2 = (TextView) findViewById(R.id.text2);
        text3 = (TextView) findViewById(R.id.text3);
        btnCalculate = (Button) findViewById(R.id.calculate);
        btnReset = (Button) findViewById(R.id.reset);
        bmi = (TextView) findViewById(R.id.result);
        bmiCategory = (TextView) findViewById(R.id.bmiCategory);
        healthRisk = (TextView) findViewById(R.id.healthRisk);

        btnCalculate.setOnClickListener(this);
        btnReset.setOnClickListener(this);
        loadData();
        updateViews();



        Button SHOW = (Button)findViewById(R.id.show);
        SHOW.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MyCustomAlertDialog();
            }
        });



    }

    @Override
    public void onClick(View v) {

        switch (v.getId()){
            case R.id.calculate:

                try {
                    saveData();
                    double weightValue = Double.parseDouble(weight.getText().toString());
                    double heightValue = Double.parseDouble(height.getText().toString());
                    double heightMeter = heightValue / 100;

                    double bmiValue = weightValue / (heightMeter * heightMeter);
                    String result = String.format("%.2f", bmiValue); //Change to 2 Decimal Places

                    if (bmiValue <= 18.4) {
                        text1.setText("Result:");
                        text2.setText("Health Risk:");
                        text3.setText("BMI Category:");

                        bmi.setText(result + " kg/m²");
                        bmiCategory.setText("Underweight");
                         healthRisk.setText("Malnutrition Risk");
                        Toast.makeText(this, "You should eat more!", Toast.LENGTH_SHORT).show();
                    } else if (bmiValue > 18.4 && bmiValue <= 24.9) {
                        text1.setText("Result:");
                        text2.setText("Health Risk:");
                        text3.setText("BMI Category:");
                        bmi.setText(result + " kg/m²");
                        bmiCategory.setText("Normal Weight");
                        healthRisk.setText("Low Risk");
                        Toast.makeText(this, "Keep the great work!", Toast.LENGTH_SHORT).show();
                    } else if (bmiValue > 24.9 && bmiValue <= 29.9) {
                        text1.setText("Result:");
                        text2.setText("Health Risk:");
                        text3.setText("BMI Category:");
                        bmi.setText(result + " kg/m²");
                        bmiCategory.setText("Overweight");
                        healthRisk.setText("Enhanced Risk");
                        Toast.makeText(this, "You should be careful, g!", Toast.LENGTH_SHORT).show();
                    } else if (bmiValue > 29.9 && bmiValue <= 34.9) {
                        text1.setText("Result:");
                        text2.setText("Health Risk:");
                        text3.setText("BMI Category:");
                        bmi.setText(result + " kg/m²");
                        bmiCategory.setText("Moderately Obese");
                        healthRisk.setText("Medium Risk");
                        Toast.makeText(this, "Take a good care of your nutrition intake and exercise often!", Toast.LENGTH_SHORT).show();
                    } else if (bmiValue > 34.9 && bmiValue <= 39.9) {
                        text1.setText("Result:");
                        text2.setText("Health Risk:");
                        text3.setText("BMI Category:");
                        bmi.setText(result + " kg/m²");
                        bmiCategory.setText("Severely Obese");
                        healthRisk.setText("High Risk");
                        Toast.makeText(this, "Get a trainer please!", Toast.LENGTH_SHORT).show();
                    } else {
                        text1.setText("Result:");
                        text2.setText("Health Risk:");
                        text3.setText("BMI Category:");
                        bmi.setText(result + " kg/m²");
                        bmiCategory.setText("Very Severely Obese");
                        healthRisk.setText("Very High Risk");
                        Toast.makeText(this, "You should see a doctor!", Toast.LENGTH_SHORT).show();
                    }
                }
                catch (java.lang.NumberFormatException nfe) {
                    Toast.makeText(this, "Please Enter A Valid Number", Toast.LENGTH_SHORT).show();
                }
                catch (Exception exp) {
                    Toast.makeText(this, "Please Enter A Valid Number", Toast.LENGTH_SHORT).show();
                }
                break;

            case R.id.reset:
                text1.setText("");
                text2.setText("");
                text3.setText("");
                bmi.setText("");
                height.setText("");
                weight.setText("");
                healthRisk.setText("");
                bmiCategory.setText("");
                Toast.makeText(this, "Text Cleared", Toast.LENGTH_LONG).show();

                break;

        }
    }



    public void saveData() {
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        editor.putString(TEXT, height.getText().toString());
        editor.putString(TEXT2, weight.getText().toString());

        //editor.putBoolean(SWITCH1, switch1.isChecked());

        editor.apply();
    }

    public void loadData() {
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
        heightString = String.valueOf(height);
        heightString = sharedPreferences.getString(TEXT, "");
        weightString = String.valueOf(weight);
        weightString = sharedPreferences.getString(TEXT2, "");
    }

    public void updateViews() {
        height.setText(heightString);
        weight.setText(weightString);
    }
    public boolean onCreateOptionsMenu (Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate (R.menu.menu, menu);

        return true;
    }

    public boolean onOptionsItemSelected(MenuItem Item){
        switch(Item.getItemId()) {
            case R.id.about:
                 intent = new Intent(this, about.class);
                startActivity(intent);
                Toast.makeText(this, "This is About Page", Toast.LENGTH_LONG).show();
                break;
            case R.id.bmiCalc:
                intent = new Intent(this, MainActivity.class);
                startActivity(intent);
                break;
            default:
                return super.onOptionsItemSelected(Item);
        }
        return true;
    }

    public void MyCustomAlertDialog(){
        final Dialog MyDialog = new Dialog(MainActivity.this);
        MyDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        MyDialog.setContentView(R.layout.customdialog);


        Button close = (Button)MyDialog.findViewById(R.id.close);


        close.setEnabled(true);


        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MyDialog.cancel();
            }
        });

        MyDialog.show();
    }





}


